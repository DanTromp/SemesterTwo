﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assignment3
{
    public partial class Database : Form
    {
        public Database()
        {
            InitializeComponent();
        }

        private void Database_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the '_std_12002076DataSet.tblClient' table. You can move, or remove it, as needed.
            this.tblClientTableAdapter.Fill(this._std_12002076DataSet.tblClient);

        }
    }
}
