﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment3
{
    public partial class ShootingRangeManager : Form
    {
        string connectionString = Properties.Settings.Default.ConnectionString;

            SqlConnection dbConn;

            SqlDataAdapter dAdapter;
            DataSet dSet;

            string name = "";
            string surname = "";
 

        public ShootingRangeManager()
        {
            InitializeComponent();

            try
            {
                // Create the connection object once - do not connect
                dbConn = new SqlConnection(connectionString);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Adding_Load(object sender, EventArgs e)
        {

        }

        private void btnViewDatabase_Click(object sender, EventArgs e)
        {

            dbConn.Open();

            // Set up the SQL command
            string sql = "SELECT * FROM tblClient";
            SqlCommand dbCommand = new SqlCommand(sql, dbConn);

            

            // Create the reader
            SqlDataReader dbReader = dbCommand.ExecuteReader();
           

               
        
        
        }
 


        }
    }

