﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment1
{
    class Births : Basics
    {
        private string p;
        private string p_2;
        private string p_3;
        private string p_4;
        private string p_5;
        private string p_6;
        private string p_7;
        private string p_8;
        private string p_9;

        public Births(string p, string p_2, string p_3, string date, string p_4, string p_5, string p_6, string p_7, string p_8, string p_9)
        {
            // TODO: Complete member initialization
            this.p = p;
            this.p_2 = p_2;
            this.p_3 = p_3;
            this.date = date;
            this.p_4 = p_4;
            this.p_5 = p_5;
            this.p_6 = p_6;
            this.p_7 = p_7;
            this.p_8 = p_8;
            this.p_9 = p_9;
        }

        public string generateReport()
        {
            string s = ("First Name: " + p + "\n" + "Last Name: " + p_2 + "\n" + "ID Number: " + p_3 + "\n" +
                        "Birth Date: " + date + "\n" + "Address: " + p_4 + "\n" + "Cell Number: " + p_5 + "\n" +
                        "Home Number: " + p_6 + "\n" + "Child's Name: " + p_7 + "\n" + "City where born: " + p_8 + "\n" +
                        "Current Location: " + p_9);

            return s;
        }
    }
}
