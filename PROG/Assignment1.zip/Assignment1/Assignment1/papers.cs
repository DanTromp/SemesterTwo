﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;



namespace Assignment1
{

    public partial class papers : Form
    {
        int[] newArray = new int[20];
        int[] newArray1 = new int[10];
        int[] newArray2 = new int[5];
        string date = "";
        int first = 0;
        double second = 0;
        int third = 0;
        int fourth = 0;
        int final = 0;

        public papers()
        {
            InitializeComponent();
        }


        private void btnGenerate_Click(object sender, EventArgs e)
        {
            //Generating the ID
            Random numb = new Random();
            double s = 0;
            int country = 0;


            if (rbMale.Checked == true)
            {
                s = numb.Next(1000, 5000);
            }

            else if (rbFemale.Checked == true)
            {
                s = numb.Next(5000, 10000);
            }

            if (rbYes.Checked == true)
            {
                country = 0;
            }

            else if (rbNo.Checked == true)
            {
                country = 1;
            }

            //Making the selected items from the combo box to a string to be used to make the ID
            
            string year = comboYear.SelectedItem + "";
            string month = comboMonth.SelectedItem + "";
            string day = comboDay.SelectedItem + "";
           
            //Getting the last 2 digits of the year of birth
            date = year.Substring(2,2) + month + day;

            //Whole generated ID number as a string
            string generated = date + s + country + "8";


            //Calculating the last digit to make sure the ID is verified

            for (int i = 0; i < generated.Length; i++)
            {
                newArray[i] = int.Parse(generated.Substring(i, 1));
            }



            for (int z = 1; z < newArray.Length; z += 2)
            {
                first = first + newArray[z];
            }



            for (int x = 0; x < newArray.Length; x += 2)
            {
                second = second + newArray[x];
            }

            string seconds = second + "";

            second = second * 2;

            for (int c = 0; c < seconds.Length; c++)
            {
                newArray1[c] = int.Parse(seconds.Substring(c, 1));
            }


            for (int v = 0; v < newArray1.Length; v++)
            {
                third = third + newArray1[v];
            }

            fourth = first + third;

            string fourths = fourth + "";

            for (int b = 0; b < fourths.Length; b++)
            {
                newArray2[b] = int.Parse(fourths.Substring(b, 1));
            }

            final = 10 - newArray2[1];




            txtGenerate.Text = date + s + country + "8" + final;
        }

        //As the user continues onto the next form then the previous one is hidden
        private void btnContinue_Click(object sender, EventArgs e)
        {
            this.Hide();

            if (comboBox1.SelectedIndex == 0)
            {
                Passport psp = new Passport();
                psp.ShowDialog();

                //Sending the variables to the passport class to make the object
                Passports psps = new Passports(txtFirstNames.Text, txtSurname.Text, txtGenerate.Text, date, txtAddress.Text, txtCell.Text, txtHome.Text, psp.getCountry(), psp.getNationality(), psp.getDestination());

                //Printing out the details for the passport class
                MessageBox.Show("PASSPORT DETAILS" + "\n" + "****************" + "\n" + psps.generateReport());

            }

            else if (comboBox1.SelectedIndex == 1)
            {
                //Creating the form birthCertificate 
                BirthCertificate birth = new BirthCertificate();
                birth.ShowDialog();

                Births births = new Births(txtFirstNames.Text, txtSurname.Text, txtGenerate.Text, date, txtAddress.Text, txtCell.Text, txtHome.Text, birth.getNames(), birth.getCity(), birth.getLocation());

                MessageBox.Show("BIRTH CERTIFICATE" + "\n" + "*****************" + "\n" + births.generateReport());
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                ID ids = new ID();
                ids.ShowDialog();

                IDDocument iddoc = new IDDocument(txtFirstNames.Text, txtSurname.Text, txtGenerate.Text, date, txtAddress.Text, txtCell.Text, txtHome.Text, ids.getName(), ids.getLocations(), ids.getValid());

                MessageBox.Show("IDENTITY DOCUMENT" + "\n" + "*****************" + "\n" + iddoc.generateReport());
            }



        }

        private void txtbox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {


        }
        //when the form loads the combo boxes are populated also

        private void papers_Load(object sender, EventArgs e)
        {
            for (int y =1990; y < 2013; y++)
            {
                comboYear.Items.Add(y + 1);
            }

            for (int z = 1; z < 10; z++)
            {
                comboMonth.Items.Add("0" + z);
            }
            for (int m = 1; m < 3; m++)
            {
                comboMonth.Items.Add("1" + m);
            }

            for (int c = 1; c < 10; c++)
            {
                comboDay.Items.Add("0" + c);
            }
        
           for (int n = 10; n < 20; n++)
			{
                comboDay.Items.Add(n);
			}

           for (int b = 20; b < 30; b++)
           {
               comboDay.Items.Add(b);
           }

           for (int a =30; a < 32; a++)
           {
               comboDay.Items.Add(a);
           }
        
        }
    }
}