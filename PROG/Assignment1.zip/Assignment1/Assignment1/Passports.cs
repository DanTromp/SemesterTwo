﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment1
{
    class Passports : Basics
    {
        private string p;
        private string p_2;
        private string p_3;
        private string p_4;
        private string p_5;
        private string p_6;
        private object p_7;
        private object p_8;
        private object p_9;

        public Passports(string p, string p_2, string p_3, string date, string p_4, string p_5, string p_6, object p_7, object p_8, object p_9)
        {
            // TODO: Complete member initialization
            this.p = p;
            this.p_2 = p_2;
            this.p_3 = p_3;
            this.date = date;
            this.p_4 = p_4;
            this.p_5 = p_5;
            this.p_6 = p_6;
            this.p_7 = p_7;
            this.p_8 = p_8;
            this.p_9 = p_9;
        }
         
            

        public string generateReport()
        {
            string s = ("First Name: " +p + "\n" + "Last Name: " + p_2 + "\n" + "ID Number: " + p_3 + "\n" + 
                        "Birth Date: " + date + "\n" + "Address: " + p_4 + "\n" + "Cell Number: " + p_5 + "\n" +
                        "Home Number: " + p_6 + "\n" + "Country Issued: " + p_7 + "\n" + "Nationality: " + p_8 + "\n" +
                        "Destination: " + p_9);

            return s;
        }
   }
}
