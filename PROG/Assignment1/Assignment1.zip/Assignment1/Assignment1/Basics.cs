﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment1
{
    class Basics
    {
        internal string firstName = "";
        internal string lastName;
        internal string idNumber;
        internal string date;
        internal string address;
        internal string cell;
        internal string home;
        

        public Basics(string p, string p_2, string p_3, string date, string p_4, string p_5, string p_6)
        {
            // TODO: Complete member initialization
            this.firstName = p;
            this.lastName = p_2;
            this.idNumber = p_3;
            this.date = date;
            this.address = p_4;
            this.cell = p_5;
            this.home = p_6;

            
          
        }

        public Basics()
        {
            
        }
        

   


        





    }
}
